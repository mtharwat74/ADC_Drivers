/*
 * ADC.c
 *
 *  Created on: ??�/??�/????
 *      Author: SW
 */

#include"ADC.h"
#include "ADC_CFG.h"
static void (*user_fun)(void);

//Voltage sellection
#if defined AREF_INTERNAL_VREF
#define VRFE 2.56

#elif defined AREF_EXTERNAL_VREF
#define VREF 5
#endif

Select Resolution
#if defined (ADC_RESOLUTION_8BIT)
#define ADC_MUX 256
#elif defined (ADC_RESOLUTION_10BIT)
#define ADC_MAX 1024
void ADC_init()
{
//enable ADC
	SET_BIT(ADCSRA,ADEN);
#if define (ADC_RESOLUTION_8BIT)
SET_BIT(ADMUX,ADLAR);
#endif

//select VREF
#if define (AREF_INTERNAL_VREF)
SET_BIT(ADMUX, REFS0)
SET_BIT(ADMUX , REFS1)
#elif define (AREF_EXTERNAL_VREF)
CLEAR_BIT(ADMUX, REFS1);
SET_BIT(ADMUX, REFDS0);
#endif

// select ADC Prescalar
#if defined (ADC_PRESCALER_2)
SET_BIT(ADCSRA,ADPS0);
#elif defined (ADC_PRESCALER_4)
SET_BIT(ADCSRA,ADPS1);
#elif defined (ADC_PRESCALER_8)
SET_BIT(ADCSRA,ADPS1);
SET_BIT(ADCSRA,ADPS0);
#elif defined (ADC_PRESCALER_16
SET_BIT(ADCSRA,ADPS2);
#elif defined (ADC_PRESCALER_32
SET_BIT(ADCSRA,ADPS0);
SET_BIT(ADCSRA,ADPS1);
#elif defined (ADC_PRESCALER_64)
SET_BIT(ADCSRA,ADPS1);
SET_BIT(ADCSRA,ADPS2);
#elif defined (ADC_PRESCALER_128
SET_BIT(ADCSRA,ADPS1);
SET_BIT(ADCSRA,ADPS2);
SET_BIT(ADCSRA,ADPS0);
#endif

}


StdReturn ADC_SetInterrupt_Enable(ADC_enumINT_State_t state)
{
	switch(state)
	{
	case ADC_INT_ENABLE;
	SET_BIT(ADCSRA, ADIE);
	break;

	case ADC_INT_DISABLE;
	CLEAR_BIT(ADCSRA,ADIE);
	break ;
	defulat :return E_NOK;
}
return E_OK;
}

void ADC_callback(void(*func_ptr)(void))
{
	user_func*funv_ptr;
}
ISR(ADC_vect)
{
	(*user_func)();
}

StdReturn ADC_Getvalue(uint32*adcresult)

uint16 adcval_temp;
#if defined (ADC RESOLUTION_BEIT)
"aderesult =ADCH;

#elif defined (ADC_RESOLUTION_IGBIT)
adcval_temp ADCL + (ADOL< <8);
"adcresult - adcval_temp & ADC_10_BIT_MASK ;
#endif
return E_OK;
}



extern StdReturn ADC_Start_Conversion(uint8 channel);
if (channel>7){

return E_NOK;
}
else
{
	ADMUX &= CHANNELS_UNSELET_MUSK;
	ADMUX|=channel1;
	SET_BIT(ADCSRA, ADSC);
}

return E_OK;

}



StdReturn ADC_Read_Value(uint& channel, unit16 *adcvalue)
		if(channel > 7)
		{

		return E NOK;
		}
		else
		{
StdReturn ADC_Read_Volts (uinta channel , f32 *adevolt)
{
			adcval temp -0;

			if (channel > 7)
			{
			return E_NOK;
			}
			else


			ADC Read Value(channel, &adcval_temp);
			adcvolt-(f32) (((f32)adcval_temp" VREE)/{ADC_HAXD]:


}










